# Grade analysis lab

The goal of this lab is to analyse a real world collection of marks
(grades) obtained by students during a semester. 
